const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

const params = {
  TableName : 'tab_prova_hw3'
}

async function listItems(){
  try {
    const data = await docClient.scan(params).promise()
    return data
  } catch (err) {
    return err
  }
}

exports.handler = async (event, context) => {
  try {
    const data = await listItems()
    var pollo=JSON.stringify(data);
    //console.log(pollo);
  var pillo= JSON.parse(pollo);
  var ak=10;
 //console.log("dsidj" +Object.keys(pillo).length)
  var n_elementi=Object.values(pillo)[1]; 
  var oggetto=Object.values(pillo)[0];
  var array=[];
  
  for(var i=0; i<n_elementi; i++){
    array.push("Gara"+ (i+1));
    array.push(oggetto[i].race_name);
    array.push(oggetto[i].race_date);
    array.push(oggetto[i].race_id);
    array.push("    ")
    console.log(oggetto[i].race_name);
    console.log(oggetto[i].race_date);
    console.log(oggetto[i].race_id)
    
  }
  
  return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json'},
    'body':array.toString()
}
  } 
  catch (err) {
    return { error: err }
  }     

}