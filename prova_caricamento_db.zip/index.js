console.log('Loading function');
const aws = require('aws-sdk');
const AWS = require("aws-sdk");
const s3 = new aws.S3({ apiVersion: '2006-03-01' });
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
    var DOMParser = new (require('xmldom')).DOMParser;
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };
      const bucket ="bucketlucal";
    const key = "ResultList1.xml";
      const params = {
        Bucket: bucket,
        Key: key,
    };
  const  data=( await (s3.getObject(params).promise())).Body.toString('utf-8');
        var document = DOMParser.parseFromString(data, "text/xml");
  var ak;
  
  var xml2js = require('xml2js');
  var parser = new xml2js.Parser({ignoreAttrs : false, mergeAttrs : false});
  parser.parseString(document, function (err, result) {
  ak=result;
});
        await dynamo
          .put({
            TableName: "Tab_prova_exe",
            Item: {
              event_name:  Object.values(ak.ResultList.Event)[0].Name[0],
              event_start_date: Object.values(ak.ResultList.Event)[0].StartTime[0].Date[0],
              event_start_time: Object.values(ak.ResultList.Event)[0].StartTime[0].Time[0],
              event_end_date:Object.values(ak.ResultList.Event)[0].EndTime[0].Date[0],
              event_end_time:Object.values(ak.ResultList.Event)[0].EndTime[0].Time[0],
              class_id:Object.values(ak.ResultList.ClassResult)[0].Class[0].Id[0],
              class_name:Object.values(ak.ResultList.ClassResult)[0].Class[0].Name[0],
              course_length:Object.values(ak.ResultList.ClassResult)[0].Course[0].Length[0],
              course_climb:Object.values(ak.ResultList.ClassResult)[0].Course[0].Climb[0],
              person_id:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Id[0],
              person_name_family:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Name[0].Family[0],
              person_name_given:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Name[0].Given[0],
              person_organisation_id:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Id[0],
              person_organisation_name:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Name[0],
              person_organisation_coutry:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Country[0]._,
              person_result_bibnumber:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].BibNumber[0],
              person_result_start:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].StartTime[0],
              person_result_finish:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].FinishTime[0],
              person_result_time:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].Time[0],
              person_result_tbehind:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].TimeBehind[0],
              person_result_position:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].Position[0]
            }
          })
          .promise();
          console.log(Object.values(ak.ResultList.Event)[0].Name[0])
        body = `Put item ${Object.values(ak.ResultList.Event)[0].Name[0]}`;
          return {
    statusCode,
    body,
    headers
  };
};