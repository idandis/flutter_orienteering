console.log('Loading function');
const aws = require('aws-sdk');
const AWS = require("aws-sdk");
const s3 = new aws.S3({ apiVersion: '2006-03-01' });
var AWS2 = require('aws-sdk');
AWS2.config.region = 'us-east-1';
const dynamo = new AWS.DynamoDB.DocumentClient();
var lambda = new AWS2.Lambda();
var token=0;
exports.handler=function(event, context)  {
  //PARTE CONTROLLO PASS------------------------
  var params2 = {
    FunctionName: 'http-crud-tutorial-function', // the lambda function we are going to invoke
    InvocationType: 'RequestResponse',
    LogType: 'Tail',
    Payload: '{"routeKey": "GET /items/{id}","id": "wdwdwd"}'
  };
  
   
   lambda.invoke(params2,  async function(err, data2,callback) {
    
    if (err) {
      console.log("POLLO")
      context.fail(err);
    } 
     if(data2.Payload=="true"){
    console.log("OOOOOOOK");
    token=1; 

  
 
 
  //-----------------------------------------
  
   
  
    var DOMParser = new (require('xmldom')).DOMParser;
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };
      const bucket ="bucketlucal";
    const key = "ResultList1.xml";
      const params = {
        Bucket: bucket,
        Key: key,
    };
  const  data=( await (s3.getObject(params).promise())).Body.toString('utf-8');
        var document = DOMParser.parseFromString(data, "text/xml");
  var ak;
  
  var xml2js = require('xml2js');
  var parser = new xml2js.Parser({ignoreAttrs : false, mergeAttrs : false});
  parser.parseString(document, function (err, result) {
  ak=result;

})


  var classresult = document.getElementsByTagName('ClassResult');
  //Get the <node> tags
    var n_classresult = classresult.length;
   
  console.log(n_classresult);
//----------------------------------------------------------------------------------------------------------
               for(var i=0; i<n_classresult;i++){
                 
               
               var class_id=Object.values(ak.ResultList.ClassResult)[i].Class[0].Id[0];
              var class_name=Object.values(ak.ResultList.ClassResult)[i].Class[0].Name[0];
              var course_length=Object.values(ak.ResultList.ClassResult)[i].Course[0].Length[0];
              var course_climb=Object.values(ak.ResultList.ClassResult)[i].Course[0].Climb[0];
             var builder = new xml2js.Builder();
            var xml = builder.buildObject(Object.values(ak.ResultList.ClassResult)[i]);
           
           var document = DOMParser.parseFromString(xml, "text/xml");
              var persone = document.getElementsByTagName('PersonResult');
               var n_personresult= persone.length;
               console.log("ECCOLO!!!"+n_personresult)
              for(var j=0; j<n_personresult;j++){
             var  person_id= Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Person[0].Id[0];
             var person_name_family=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Person[0].Name[0].Family[0];
              var person_name_given=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Person[0].Name[0].Given[0];
              var person_organisation_id=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Organisation[0].Id[0];
              var person_organisation_name=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Organisation[0].Name[0];
              var person_organisation_coutry=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Organisation[0].Country[0]._;
              var person_result_start=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].StartTime[0];
              if(Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].TimeBehind!=undefined){
             var person_result_tbehind=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].TimeBehind[0];
             var person_result_position=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].Position[0];
              var person_result_bibnumber=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].BibNumber[0];
              var person_result_finish=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].FinishTime[0];
              var person_result_time=Object.values(ak.ResultList.ClassResult)[i].PersonResult[j].Result[0].Time[0];
              console.log("OK");
              }
              else {
                var person_result="NULL";
                var person_result_position="NULL";
                var person_result_bibnumber="NULL";
                var person_result_finish="NULL";
                var person_result_time="NULL";
              }
              
              
               
//---------------------------------------------------------------------------------------------------------
        await dynamo.put({
            TableName: "ciclo_for",
            Item: {
              id_persona:  person_id,
              event_start_date: Object.values(ak.ResultList.Event)[0].StartTime[0].Date[0],
              event_start_time: Object.values(ak.ResultList.Event)[0].StartTime[0].Time[0],
              event_end_date:Object.values(ak.ResultList.Event)[0].EndTime[0].Date[0],
              event_end_time:Object.values(ak.ResultList.Event)[0].EndTime[0].Time[0],
              class_id:class_id,
              class_name:class_name,
              course_length:course_length,
              course_climb:course_climb,
              person_name_family:person_name_family,
              person_name_given:person_name_given,
              person_organisation_id:person_organisation_id,
              person_organisation_name:person_organisation_name,
              person_organisation_coutry:person_organisation_coutry,
              person_result_bibnumber:person_result_bibnumber,
              person_result_start:person_result_start,
              person_result_finish:person_result_finish,
              person_result_time:person_result_time,
              person_result_tbehind:person_result_tbehind,
              person_result_position:person_result_position,
            
              
              }
          })
          .promise();
              }
               }
          
          console.log("ULTIMO CONSOLE LOG"+Object.values(ak.ResultList.Event)[0].Name[0])
        body = `Put item ${Object.values(ak.ResultList.Event)[0].Name[0]}`;
          return {
    
    body,
    
  };

     }
   
     
    
})
};

/*              event_start_date: Object.values(ak.ResultList.Event)[0].StartTime[0].Date[0],
              event_start_time: Object.values(ak.ResultList.Event)[0].StartTime[0].Time[0],
              event_end_date:Object.values(ak.ResultList.Event)[0].EndTime[0].Date[0],
              event_end_time:Object.values(ak.ResultList.Event)[0].EndTime[0].Time[0],
              
              class_id:class_id,
              class_name:class_name,
              course_length:course_length,
              course_climb:course_climb,
              /*person_id:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Id[0],
              person_name_family:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Name[0].Family[0],
              person_name_given:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Person[0].Name[0].Given[0],
              person_organisation_id:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Id[0],
              person_organisation_name:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Name[0],
              person_organisation_coutry:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Organisation[0].Country[0]._,
              person_result_bibnumber:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].BibNumber[0],
              person_result_start:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].StartTime[0],
              person_result_finish:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].FinishTime[0],
              person_result_time:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].Time[0],
              person_result_tbehind:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].TimeBehind[0],
              person_result_position:Object.values(ak.ResultList.ClassResult)[0].PersonResult[0].Result[0].Position[0],*/