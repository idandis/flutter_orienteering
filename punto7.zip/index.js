const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

const params = {
  TableName : 'tab_prova_hw3'
}

async function listItems(){
  try {
    const data = await docClient.scan(params).promise()
    return data
  } catch (err) {
    return err
  }
}

exports.handler = async (event, context) => {
  

 
  try {
    const data = await listItems()
    var pollo=JSON.stringify(data);
    //console.log(pollo);
  var pillo= JSON.parse(pollo);
  var ak=10;
 //console.log("dsidj" +Object.keys(pillo).length)
  var n_elementi=Object.values(pillo)[1]; 
  var oggetto=Object.values(pillo)[0];
  var array=[];
  var classifica=[];
  for(var i=0; i<n_elementi; i++){
    if(oggetto[i].id==event.id){
        console.log("entrato");
        if(oggetto[i].classe==event.class){
            console.log("entrato");
            
              classifica.push("Gara"+ (i+1));
              classifica.push(oggetto[i].race_name);
              classifica.push(oggetto[i].race_date);
              classifica.push(oggetto[i].race_id);
              classifica.push("Posizione:");
              classifica.push(oggetto[i].posizione);
              classifica.push("    ")
        }
      
    }
  }
  return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json'},
    'body': classifica.toString()
}
  } 
  catch (err) {
    return { error: err }
  }    

}